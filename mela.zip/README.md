# Flet app

A simple Flet app.

To run the app:

```
flet run [app_directory]
```
1000, 1225